package main;

import ExecutaMonolitico.MainFrm;

public class Main {
	public static void main(String[] args) {
		//tela inicio
		new MainFrm();
	}
}
