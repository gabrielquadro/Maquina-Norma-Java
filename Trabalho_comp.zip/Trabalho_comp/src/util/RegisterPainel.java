package util;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
@SuppressWarnings("serial")
public class RegisterPainel extends JPanel{
	//painel dos registradores
	
		//nome a digitar
		private JTextField nmRegistrador;
		//valor a digiar 
		private JTextField vlRegistrador;
		//label nome
		private JLabel lbelRegName;
		//label valor
		private JLabel lbelRegValue;
		
		public RegisterPainel(int number) {
			
			this.setBackground(Color.cyan);
			//nome reg
			lbelRegName = new JLabel("Register " + number + "  Name:");
			nmRegistrador = new JTextField(3);
			nmRegistrador.setHorizontalAlignment(JTextField.CENTER);
			//valor
			lbelRegValue = new JLabel("Value:");
			vlRegistrador = new JTextField(3);
			vlRegistrador.setHorizontalAlignment(JTextField.CENTER);
			
			
			//add em tela
			this.add(lbelRegName);
			this.add(nmRegistrador);
			this.add(lbelRegValue);
			this.add(vlRegistrador);
		}
		
		//get e set dos textfield

		public JTextField getNmRegistrador() {
			return nmRegistrador;
		}

		public void setNmRegistrador(JTextField nmRegistrador) {
			this.nmRegistrador = nmRegistrador;
		}

		public JTextField getVlRegistrador() {
			return vlRegistrador;
		}

		public void setVlRegistrador(JTextField vlRegistrador) {
			this.vlRegistrador = vlRegistrador;
		}
		
		
}
