package util;

import java.math.BigInteger;

public class Register {
	//nome registrador
		private String nameReg;
		//valor registrador
		private BigInteger valueReg;
		
		//get e set
		
		public String getNameReg() {
			return nameReg;
		}
		public void setNameReg(String nmRegistrador) {
			this.nameReg = nmRegistrador;
		}
		public BigInteger getValueReg() {
			return valueReg;
		}
		public void setValueRegister(BigInteger vlRegistrador) {
			this.valueReg = vlRegistrador;
		}
		
}
