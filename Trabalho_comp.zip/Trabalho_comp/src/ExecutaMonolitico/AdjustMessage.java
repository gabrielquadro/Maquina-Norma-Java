package ExecutaMonolitico;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import ExecutaMonolitico.RulesActions.RulesTypeActions;


public class AdjustMessage {

	// gera as regras
	public List<Rules> generateActions(String text) {
		List<Rules> rules = new ArrayList<Rules>();
		// le linha por linha
		List<String> lines = Arrays.asList(text.split("\n"));
		// reune as regras
		for (String rule : lines) {
			rules.add(generaeActions(rule));
		}
		return rules;
	}

	private Rules generaeActions(String instrucao) {
		String[] split = instrucao.split(":");
		RulesType ruleType = indentifieRuleTye(split[1]);

		Rules result = null;

		// verifica se � teste ou a��o
		switch (ruleType) {
		case ACTION:
			// cria a��o
			result = createAction(split);
			break;
		case TEST:
			// cria teste
			result = createTeste(split);
			break;
		default:
		}
		return result;
	}

	// caso criar a��o
	private Rules createAction(String[] rule) {
		// pega numero
		Integer numberAction = Integer.valueOf(rule[0]);

		Integer index1 = rule[1].indexOf("_");
		// tipo
		String typeRule = rule[1].substring(index1 - 3, index1).trim();
		// pega se � ad ou sub
		RulesTypeActions operationRuleType = typeRule.equals(RulesTypeActions.AD.getValue()) ? RulesTypeActions.AD
				: RulesTypeActions.SUB;

		Integer index2 = rule[1].indexOf("v�_para");
		// informa ond deve ir
		Integer instrucaoDestino = Integer.valueOf(rule[1].substring(index2 + 7).trim());
		// destino
		String regDestiny = rule[1].substring(index1 + 1, index2).trim();
		// regra a�ao
		RulesActions result = new RulesActions();
		// n�mero
		result.setNumberRules(numberAction);
		// tipo a��o
		result.setRulesType(RulesType.ACTION);
		result.setTypeRuleActions(operationRuleType);
		// destino
		result.setRulesDestination(instrucaoDestino);
		result.setRgOperation(regDestiny);
		return result;
	}

	// caso criar teste
	private Rules createTeste(String[] rule) {
		// cria��o da regra
		Integer numberRule = Integer.valueOf(rule[0]);
		// adiciona o se rgister zero
		Integer start = rule[1].indexOf("zero_");
		// add o ent�o
		Integer end = rule[1].indexOf("ent�o");
		String r = rule[1].substring(start + 5, end).trim();

		// adiona parte da regra da ocasi�o v�_para
		String subString[] = rule[1].split("v�_para ");
		// adiciona o sen�o do v�_para
		Integer end2 = subString[1].indexOf("sen�o");
		// caso true
		Integer ruleTrue = Integer.valueOf(subString[1].substring(0, end2).trim());
		// caso false
		Integer ruleFalse = Integer.valueOf(subString[2].trim());

		// teste regra
		TestRule testRule = new TestRule();
		// seta numero da regra
		testRule.setNumberRules(numberRule);
		// seta tip pra teste
		testRule.setRulesType(RulesType.TEST);

		testRule.setRegTeste(r);
		// true
		testRule.setNumberRuleTrue(ruleTrue);
		// false
		testRule.setNumberRuleFalse(ruleFalse);
		// retorna o teste da regra
		return testRule;
	}

	// identifica o tipo da regra
	private RulesType indentifieRuleTye(String rule) {
		return "se".equals(rule.substring(1, 3)) ? RulesType.TEST : RulesType.ACTION;
	}
}