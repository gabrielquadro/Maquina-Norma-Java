package ExecutaMonolitico;

public enum RulesType {
	//tipos de regras
	TEST, ACTION;
}
