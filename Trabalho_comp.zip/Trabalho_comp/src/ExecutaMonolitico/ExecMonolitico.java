package ExecutaMonolitico;

import java.math.BigInteger;
import java.util.List;
import java.util.NoSuchElementException;

import ExecutaMonolitico.ConsoleMonolitico;
import ExecutaMonolitico.Rules;
import ExecutaMonolitico.RulesActions;
import ExecutaMonolitico.TestRule;
import ExecutaMonolitico.RulesActions.RulesTypeActions;
import util.Register;


public class ExecMonolitico {

	// lista regras
		private List<Rules> rule;
		// lista regisradores
		private List<Register> registers;
		// programa executou?
		private Boolean programRan;
		// print console
		private ConsoleMonolitico logConsole;

		public ExecMonolitico(List<Rules> rule, List<Register> registers) {
			// regras
			this.rule = rule;
			// registradores
			this.registers = registers;
			// verifica se rodou e acabou
			this.programRan = false;
			// o que � impresso no consoes
			this.logConsole = new ConsoleMonolitico();
			// registra regras console
			logConsole.regiserRule(rule);
			// regitra e printa regisradores
			logConsole.printRegisters(registers);
		}

		public void execMonolitico() {
			//percorre regras
			Rules current = getNumberRule(1);

			// enqanto houver regra
			while (current != null) {
				// registra a regra atual
				logConsole.registerCurrentRule(current);
				Integer next = 0; // proximo
				// verifica tipo
				switch (current.getRulesType()) {
				// executa a��o
				case ACTION:
					next = doAction((RulesActions) current);
					break;
				// executa teste
				case TEST:
					next = doTest((TestRule) current);
					break;
				default:
				}

				// seta registrador e valor
				logConsole.registerRegValues(registers);
				// pega pr�xima
				current = getNumberRule(next);
			}

			// faz o registro de fim de programa
			logConsole.endProgram();

			// programa rodou e acabou
			programRan = true;
		}

		// pega o nn�mero da regra
		private Rules getNumberRule(Integer numberRules) {
			try {
				return rule.stream().filter(i -> i.getNumberRules() == numberRules).findFirst().get();
			} catch (NoSuchElementException e) {
				return null;
			}
		}

		// case test
		private Integer doTest(TestRule rule) {
			String numberReg = rule.getRegTeste();
			Register register = registers.stream().filter(f -> f.getNameReg().equals(numberReg)).findFirst().get();
			return register.getValueReg().equals(BigInteger.ZERO) ? rule.getNumberRuleTrue()
					: rule.getNrInstrucaoFalso();
		}

		// case a��o
		private Integer doAction(RulesActions current) {
			//opera��o
			String nmReg = current.getRgOperation();
			//registrador
			Register reg = registers.stream().filter(f -> f.getNameReg().equals(nmReg)).findFirst().get();
			//tipo regra
			RulesTypeActions rulesTypeAction = current.getTypeRuleActions();
			BigInteger vlReg = BigInteger.ZERO;
			switch (rulesTypeAction) {
			// caso ad
			case AD:
				//pega vaor do registrador
				vlReg = reg.getValueReg().add(BigInteger.ONE);
				break;
			// cao sub
			case SUB:
				//pega vaor do registrador
				vlReg = reg.getValueReg().subtract(BigInteger.ONE);
				break;
			default:
			}
			
			//seta o valor ou de ad ou de sub
			reg.setValueRegister(vlReg);
			
			//atualiza atual
			return current.getRulesDestination();
		}

		
		//pegar o log do console
		public StringBuilder getLogProgram() {
			return logConsole.getLog();
		}
		
		//veriica se acabou
		public Boolean finish() {
			return programRan;
		}
	
	
}
