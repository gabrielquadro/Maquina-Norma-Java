package ExecutaMonolitico;

import java.util.List;

import util.Register;


public class ConsoleMonolitico {
	
	
	private StringBuilder log;

	public ConsoleMonolitico() {
		log = new StringBuilder();
	}

	// gera o que ser� impesso no console
	public void regiserRule(List<Rules> rules) {
		log.append("RULES\n");
		log.append("\n");

		// adiciona as regras
		for (Rules r : rules) {
			// registra nome e tipo da regra
			log.append("Rule Number: " + r.getNumberRules() + "\n");
			log.append("Rule Type: " + r.getRulesType() + "\n");

			// regra a��o
			if (r instanceof RulesActions) {
				RulesActions instrucaoOperacao = (RulesActions) r;
				log.append("Register Action: " + instrucaoOperacao.getRgOperation() + "\n");
				log.append("Type: " + instrucaoOperacao.getTypeRuleActions() + "\n");
				log.append("Destination rule: " + instrucaoOperacao.getRulesDestination() + "\n");
			} else { // regra teste
				TestRule instrucaoOperacao = (TestRule) r;
				log.append("Register Test: " + instrucaoOperacao.getRegTeste() + "\n");
				log.append("Destination true: " + instrucaoOperacao.getNumberRuleTrue() + "\n");
				log.append("Destination false: " + instrucaoOperacao.getNrInstrucaoFalso() + "\n");
			}

			log.append("\n");

		}

	}

	public void printRegisters(List<Register> registers) {
		log.append("---------------------------------------------------------");

		log.append("\n\nRegisters\n\n");

		// print os registradores
		for (Register registrador : registers) {
			// nome registrador
			log.append("Name: " + registrador.getNameReg() + "\n");
			// valor
			log.append("Value: " + registrador.getValueReg() + "\n");
			
			log.append("\n");
		}
		log.append("---------------------------------------------------------\n");
	}

	// registra valores rgistradores
	public void registerRegValues(List<Register> registers) {
//		log.append("---------------------------------------------------------\n");
		for (Register register : registers) {
			log.append("(" + register.getNameReg() + "," + register.getValueReg()
					+ ")\n\n\n");
		}
		log.append("\n");
	}

	// registra a regra atual
	public void registerCurrentRule(Rules currentRule) {
		// caso a��o
		if (currentRule instanceof RulesActions) {
			RulesActions rule = (RulesActions) currentRule;
			log.append("Rule " + rule.getNumberRules() + "\n");
			// caso teste
		} else {
			TestRule instrucao = (TestRule) currentRule;
			log.append("Rule  " + instrucao.getNumberRules() + "\n");
		}

	}

	public void endProgram() {
		log.append("END\n");
	}

	public StringBuilder getLog() {
		return log;
	}
	
	
}
