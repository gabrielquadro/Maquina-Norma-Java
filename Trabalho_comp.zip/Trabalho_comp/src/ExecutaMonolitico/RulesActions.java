package ExecutaMonolitico;



public class RulesActions extends Rules{
	private Integer rulesDestination; ///destino intru��o
	private RulesTypeActions typeRuleActions; //Tipo regras Operacao
	private String rgOperation;
	
	//enum dos tipos de regra a��o
	public enum RulesTypeActions{
		AD("ad"), SUB("sub");
		
		public final String value;

	    private RulesTypeActions(String value) {
	        this.value = value;
	    }
	    
	    public String getValue() {
			return value;
		}
	}

	//get e set
	
	
	public RulesTypeActions getTypeRuleActions() {
		return typeRuleActions;
	}

	public void setTypeRuleActions(RulesTypeActions typeRuleActions) {
		this.typeRuleActions = typeRuleActions;
	}

	public Integer getRulesDestination() {
		return rulesDestination;
	}

	public void setRulesDestination(Integer rulesDestination) {
		this.rulesDestination = rulesDestination;
	}

	public String getRgOperation() {
		return rgOperation;
	}

	public void setRgOperation(String rgOperation) {
		this.rgOperation = rgOperation;
	}

	
}
