package ExecutaMonolitico;

public abstract class Rules {
	// n�mero da regra
	private Integer numberRules;
	// tipo da regra
	private RulesType rulesType;

	// getter e seters

	public Integer getNumberRules() {
		return numberRules;
	}

	public void setNumberRules(Integer number) {
		this.numberRules = number;
	}

	public RulesType getRulesType() {
		return rulesType;
	}

	public void setRulesType(RulesType type) {
		this.rulesType = type;
	}

	@Override
	public String toString() {
		return "Rules--> ( numberRules=" + numberRules + " : rulesType=" + rulesType + ")";
	}

}
