package ExecutaMonolitico;

public class TestRule extends Rules{
	private String registerTest;
	private Integer numberRuleTrue;
	private Integer numberRuleFalse;
	
	public String getRegTeste() {
		return registerTest;
	}
	public void setRegTeste(String regTeste) {
		this.registerTest = regTeste;
	}
	public Integer getNumberRuleTrue() {
		return numberRuleTrue;
	}
	public void setNumberRuleTrue(Integer nrInstrucaoVerdadeiro) {
		this.numberRuleTrue = nrInstrucaoVerdadeiro;
	}
	public Integer getNrInstrucaoFalso() {
		return numberRuleFalse;
	}
	public void setNumberRuleFalse(Integer numberRuleFalse) {
		this.numberRuleFalse = numberRuleFalse;
	}
	
	
}
