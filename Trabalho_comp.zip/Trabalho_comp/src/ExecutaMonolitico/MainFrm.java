package ExecutaMonolitico;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.ScrollPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import com.jgoodies.forms.builder.DefaultFormBuilder;
import com.jgoodies.forms.debug.FormDebugPanel;
import com.jgoodies.forms.layout.FormLayout;

import ExecutaMonolitico.AdjustMessage;
import ExecutaMonolitico.ExecMonolitico;
import ExecutaMonolitico.Rules;
import util.Register;
import util.RegisterPainel;

public class MainFrm {

	private JFrame form; // painel
	private JTextField numReg; // n�mero de registradores
	private JButton btnConfirm, btnCancel, btnExecute; // bot�es
	private JTextArea textAreaNorma; // �rea norma
	private JPanel regiterPinel; // painel esquerda
	private JPanel registrars; // registradores
	private boolean loadRegOk = false;

	public MainFrm() {

		initComponents();
		initListeners();
		initLayout();
		form.pack();
		form.setVisible(true);
		form.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	// ge do form geral
	public JFrame getForm() {
		return form;
	}

	// cria��o dos componentes da tela
	private void initComponents() {
		// cria��o dos frames e painels
		form = new JFrame("Trabalho Computabilidade");
		// pain dos regiradores
		regiterPinel = new JPanel();
		regiterPinel.setBackground(Color.cyan);
		regiterPinel.setLayout(new BorderLayout());
		// campo pega num de registradores
		numReg = new JTextField();
		// btn confirma
		btnConfirm = new JButton("Confirm");
		btnConfirm.setBackground(Color.green);
		btnConfirm.setSize(18, 18);
		btnConfirm.setBorder(BorderFactory.createEtchedBorder());
		// btn cancela
		btnCancel = new JButton("Cancel");
		btnCancel.setBackground(Color.red);
		btnCancel.setSize(18, 18);
		btnCancel.setBorder(BorderFactory.createEtchedBorder());
		// btn executa
		btnExecute = new JButton("Execute");
		// campo textarea para prgrama maquina normas
		textAreaNorma = new JTextArea();
		textAreaNorma.setBackground(Color.lightGray);
	}

	// a��es dos bot�es
	private void initListeners() {
		// confirmar pressed
		btnConfirm.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// cria os registradores na telas
				loadRegisterList();
				// ap�s pressionado seta pra false
				// verifica se tudo ok, se digitou algo
				if (loadRegOk) {
					btnConfirm.setEnabled(false);

				}
			}

		});
		// cancelar pressed
		btnCancel.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// limpa painel de registradores
				regiterPinel.removeAll();
				// reseta num de registradores
				numReg.setText("");
				// seta btn confirma pra ser clicavel novamente
				btnConfirm.setEnabled(true);
				SwingUtilities.updateComponentTreeUI(form);
			}
		});
		// executar pressed
		btnExecute.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					// gera��o dos registradoress
					List<Register> registers = generateRegisters();
					// tratar a mensagem monolitica
					AdjustMessage adjustMessage = new AdjustMessage();
					// arruma as regras
					List<Rules> rules = adjustMessage.generateActions(textAreaNorma.getText());
					ExecMonolitico execMonoltico = new ExecMonolitico(rules, registers);
					execMonoltico.execMonolitico();
					// prina no consoles
					System.out.println(execMonoltico.getLogProgram().toString());

				} catch (Exception exception) {
					// erro de imputs
					JOptionPane.showMessageDialog(form,
							"Invalid data entry. Registers or program with incorrect inputs", "Error",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});

	}

	// add registradores
	private List<Register> generateRegisters() {
		List<Register> result = new ArrayList<Register>();
		for (int i = 1; i < registrars.getComponentCount(); i++) {
			Register r = new Register();
			// add os registers no painel
			RegisterPainel regiterPainel = (RegisterPainel) registrars.getComponent(i);
			// seta nome
			r.setNameReg(regiterPainel.getNmRegistrador().getText());
			// seta valor
			r.setValueRegister(new BigInteger(regiterPainel.getVlRegistrador().getText()));

			result.add(r);
		}
		return result;
	}

	// cria a telas
	private void initLayout() {
		// cria layout
		FormLayout layout = new FormLayout("30dlu, 5dlu, 30dlu, 5dlu, 30dlu, 10dlu, 90dlu:grow",
				"18dlu, 18dlu, 18dlu, fill:90dlu, 18dlu, fill:160dlu:grow, 18dlu");

		// DefaultFormBuilder builder = new DefaultFormBuilder(layout, new
		// FormDebugPanel());
		DefaultFormBuilder builder = new DefaultFormBuilder(layout);
		builder.border(BorderFactory.createEmptyBorder(5, 5, 5, 5));

		builder.addSeparator("Number of registrars", 7);
		// builder.addLabel("Number of registrars");

		builder.nextLine();

		builder.append(numReg, btnConfirm, btnCancel);

		builder.nextLine();

		builder.addSeparator("Initialize registers", 7);

		builder.nextLine();

		builder.append(regiterPinel, 7);

		builder.nextLine();

		builder.addSeparator("Program", 7);

		builder.nextLine();

		ScrollPane scrollPane2 = new ScrollPane();
		scrollPane2.add(textAreaNorma);
		builder.append(scrollPane2, 7);

		builder.nextLine();

		builder.append(btnExecute, 7);

		form.add(builder.getPanel());
	}

	// adicion os regisradores
	private void loadRegisterList() {
		// verifica se digitou algo
		if (!"".equals(numReg.getText())) {
			// limite de 4 registradores
			if (Integer.valueOf(numReg.getText()) >= 4) {
				loadRegOk = false;
				JOptionPane.showMessageDialog(form, "Number of registrars must be less than or equal to 4", "Attention",
						JOptionPane.WARNING_MESSAGE);
			} else {
				// converte pra int
				Integer numRegInt = Integer.parseInt(numReg.getText());

				// cria o painel para os registrdores
				registrars = new JPanel();
				registrars.setBackground(Color.cyan);
				registrars.setLayout(new BoxLayout(registrars, BoxLayout.Y_AXIS));
				registrars.add(new JLabel(" "));

				// adiciona os registradores
				for (int i = 0; i < numRegInt; i++) {
					registrars.add(new RegisterPainel((i + 1)));
				}
				JPanel jpanel2 = new JPanel();
				jpanel2.setLayout(new BorderLayout());
				jpanel2.setBackground(Color.cyan);
				jpanel2.add(registrars, BorderLayout.CENTER);
				regiterPinel.add(jpanel2, BorderLayout.NORTH);

				// havia valor em num de registradores deu tudo ok
				loadRegOk = true;
			}
		} else {
			// n�o digitou nada
			loadRegOk = false;
			JOptionPane.showMessageDialog(form, "Enter the number of registrars", "Attention",
					JOptionPane.WARNING_MESSAGE);

		}
		SwingUtilities.updateComponentTreeUI(form);
	}

}
